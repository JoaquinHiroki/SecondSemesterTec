#include <iostream>
#include <vector>
#include "Dice.h"
#include "Player.h"
#include "Board.h"

#ifndef MYGAME_H_
#define MYGAME_H_

using namespace std;

class MyGame{
    private:
        vector <Player> players;
        Board board;
        Dice dice;
        int turn;

    public:
        MyGame();
        void start();
        void playTurn();
        void printTurnInfo(int turn, int playerId, int currentPosition, int diceRoll, char tileType, int finalPosition);
        void endGame();
};

#endif