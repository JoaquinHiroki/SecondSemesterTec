#include "Tile.h"

Tile::Tile(int position, char type): position(position), type(type) {}

int Tile::getPosition() const {
    return position;
}

char Tile::getType() const{
    return type;
}