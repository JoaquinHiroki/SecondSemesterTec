#include <iostream>
#include <vector>
#include "Tile.h"

#ifndef BOARD_H_
#define BOARD_H_

using namespace std;

class Board{
    private:
        vector<Tile> tiles;
    public:
        Board();
        void initializeBoard();
        Tile getTile(int position) const;
};

#endif