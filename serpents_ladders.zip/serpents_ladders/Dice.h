#include <iostream>

#ifndef DICE_H_
#define DICE_H_

using namespace std;

class Dice{
    public:
        Dice();
        int roll();
};

#endif