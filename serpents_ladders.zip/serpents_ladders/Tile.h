#include <iostream>

#ifndef TILE_H_
#define TILE_H_

using namespace std;

class Tile{
    private:
        int position;
        char type;
    public:
        Tile(int position, char type);
        int getPosition() const;
        char getType() const;
};

#endif