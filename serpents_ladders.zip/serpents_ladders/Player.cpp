#include "Player.h"

Player::Player(int id) : id(id), position(1) {}

int Player::getPosition() const{
    return position;
}

void Player::setPosition(int newposition){
    position = newposition;
}

int Player::getId() const{
    return id;
}