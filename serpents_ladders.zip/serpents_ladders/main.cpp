#include <iostream>
#include "MyGame.h"
using namespace std;

int main(){
    MyGame uwu;
    uwu.start();
    return 0;
};