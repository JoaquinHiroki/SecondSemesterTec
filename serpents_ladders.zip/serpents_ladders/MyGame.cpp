#include "MyGame.h"
#include <iostream>

using namespace std;

MyGame::MyGame() : turn(1) {
    players.push_back(Player(1));
    players.push_back(Player(2));
    board.initializeBoard();
}

void MyGame::start() {
    cout << "Press C to continue next turn, or E to end the game:" << endl;
    char command;
    while (true) {
        cin >> command;
        if (command == 'C') {
            playTurn();
        } else if (command == 'E') {
            endGame();
            break;
        } else {
            cout << "Invalid option, please press C to continue next turn or E to end the game" << endl;
        }
    }
}

void MyGame::playTurn() {
    Player& currentPlayer = players[turn % 2];
    int currentTurn = turn++;
    int currentPosition = currentPlayer.getPosition();
    int diceRoll = dice.roll();
    int newPosition = currentPosition + diceRoll;

    if (newPosition > 30) newPosition = 30;
    Tile newTile = board.getTile(newPosition);
    char tileType = newTile.getType();

    if (tileType == 'S') {
        newPosition -= 3;
    } else if (tileType == 'L') {
        newPosition += 3;
    }

    currentPlayer.setPosition(newPosition);
    printTurnInfo(currentTurn, currentPlayer.getId(), currentPosition, diceRoll, tileType, newPosition);

    if (newPosition >= 30) {
        cout << "-- GAME OVER --" << endl;
        cout << "Player " << currentPlayer.getId() << " is the winner!!!" << endl;
        exit(0);
    }
}

void MyGame::printTurnInfo(int turn, int playerId, int currentPosition, int diceRoll, char tileType, int finalPosition) {
    cout << turn << " " << playerId << " " << currentPosition << " " << diceRoll << " " << tileType << " " << finalPosition << endl;
}

void MyGame::endGame() {
    cout << "Thanks for playing!!!" << endl;
}
