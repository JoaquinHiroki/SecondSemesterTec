#include "Board.h"
#include "Tile.h"

Board::Board() {
    initializeBoard();
}

void Board::initializeBoard(){
    for (int i = 1; i <= 30; i++){
        if (i == 6 || i == 14 || i ==2) {
            tiles.push_back(Tile(i, 'S'));
        } else if (i == 4 || i == 12 || i == 20) {
            tiles.push_back(Tile(i, 'L'));
        } else {
            tiles.push_back(Tile(i, 'N'));
        }
    }
}

Tile Board::getTile(int position) const{
    if (position < 1 || position > 30){
        return Tile(1, 'N');
    }
    return tiles[position - 1];
    
}