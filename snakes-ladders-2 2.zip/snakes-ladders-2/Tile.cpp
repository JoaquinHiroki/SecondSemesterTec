//Tile.cpp
#include "Tile.h"