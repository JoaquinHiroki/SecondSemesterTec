#ifndef DICE_H_
#define DICE_H_

#include <iostream>

using namespace std;

class Dice {
    public:
        Dice();
        int roll();
};

#endif
