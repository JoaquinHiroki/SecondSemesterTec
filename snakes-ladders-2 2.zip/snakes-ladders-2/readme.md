# Participants:
José Pablo López Rodríguez 
Luis Carlos Marrufo Padilla 
Joaquín Hiroki Campos Kishi 
Leonardo Macias

# Snakes and Ladders Game Simulation
This project is a simplified and modified version of the classic Snakes and Ladders game implemented in C++. The game supports 2 players and follows the rules described below.

## Board Features
1. The board contains 30 tiles.
2. The board contains 3 snake-type squares indicated by the letter `S` (snakes).
3. The board contains 3 ladder-type squares with the letter `L` (ladders).
4. The remaining squares are normal squares indicated by the letter `N`.
5. Each snake square moves the player back 3 squares (penalty).
6. Each ladder square moves the player forward 3 additional squares (reward).
7. Each square is identified by a natural number starting from 1.

## Player Features
1. The game supports 2 players.
2. Each player is identified with a natural number starting from 1.
3. At the beginning of the game, all players start at square 1.
4. Player 1 starts the first turn of the game.

## Game Features
1. The game consists of a succession of turns.
2. Each turn can be executed with the following commands:
   - Enter the letter "C" (continue) to continue the game with the next turn.
   - Enter the letter "E" (end) to end the game.
3. Only before the first turn should the following instruction menu be printed:
   - `Press C to continue next turn, or E to end the game:`
4. If the key entered is not "C" or "E", the following message should be printed:
   - `Invalid option, please press C to continue next turn or E to end the game`

### Turn Execution
During each turn, the following information must be printed:
1. The turn number (the first turn is indicated by the number 1).
2. The player number with the current turn.
3. The square number corresponding to the player's current position.
4. The number obtained by simulating a conventional 6-sided die.
5. The type of square the player should move to after throwing the dice:
   - `N` for normal squares
   - `S` for snake squares
   - `L` for ladder squares
6. The final square to which the player must move:
   - If the square is normal, then indicate the final position directly.
   - If the square is a ladder, the final position will be the result of the corresponding increment in squares indicated by the reward.
   - If the square is a snake, the final position will be the result of the corresponding decrement in squares indicated by the penalty.
   - If a special square (snake or ladder) results in the player landing on another special square, the second should be ignored (only one jump or one recoil per turn is allowed).

### End of Game
1. The game ends if:
   - A player wins by reaching or exceeding the final square.
   - The maximum number of turns has been reached.
   - A player chooses to end the game by entering "E".
2. Once the game is over, the message `-- GAME OVER --` must be printed.
3. If the maximum number of turns has been reached, print: `The maximum number of turns has been reached...`
4. If a player wins, print: `Player # is the winner!!!`
5. If the game ends by entering "E", print: `Thanks for playing!!!`

## Technical Specifications
1. Write a `main` method that initializes the game.
2. The `main` method must be in a file named `main.cpp`.
3. Write a class named `MyGame` that contains the attributes and methods needed to represent the game.
4. Within the `MyGame` class, create a method called `start` that starts running the game.
5. In the `main` method, create a new instance of your game and call the `start` method.
6. Use the die provided in the `Dice` class and its `roll` method to simulate the dice.