//Joaquín Hiroki Campos Kishi A01639134

#include <iostream>
#include <fstream>
#include <string>
#include "Fraction.h"
#include "MatFrac.h"

int main() {
    std::string matrix1File, matrix2File, sumFile; //ask for the files
    std::cout << "File of the first matrix: ";
    std::cin >> matrix1File;
    std::cout << "File of the second matrix: ";
    std::cin >> matrix2File;
    std::cout << "File for the result: ";
    std::cin >> sumFile;

    std::ifstream file1(matrix1File), file2(matrix2File); //read the files
    if (!file1.is_open() || !file2.is_open()) {
        std::cerr << "Error" << std::endl;
        return 1;
    }

    std::vector<std::vector<Fraction>> mat1, mat2;
    int num_rows, num_cols;

    file1 >> num_rows >> num_cols;
    mat1.resize(num_rows, std::vector<Fraction>(num_cols));
    for (int i = 0; i < num_rows; ++i) {
        for (int j = 0; j < num_cols; ++j) {
            int num, den;
            file1 >> num >> den;
            mat1[i][j] = Fraction(num, den);
        }
    }

    file2 >> num_rows >> num_cols;
    mat2.resize(num_rows, std::vector<Fraction>(num_cols));
    for (int i = 0; i < num_rows; ++i) {
        for (int j = 0; j < num_cols; ++j) {
            int num, den;
            file2 >> num >> den;
            mat2[i][j] = Fraction(num, den);
        }
    }

    MatFrac m1(mat1);
    MatFrac m2(mat2);

    MatFrac sumMatrix = m1.addMatrices(m2);

    std::ofstream outputFile(sumFile);
    if (!outputFile.is_open()) {
        std::cerr << "Error" << std::endl;
        return 1;
    }

    outputFile << sumMatrix.getRows() << " " << sumMatrix.getCols() << std::endl;
    for (const auto& row : sumMatrix.getMatrix()) {
        for (const auto& elem : row) {
            outputFile << elem.getNum() << " " << elem.getDen() << " ";
        }
        outputFile << std::endl;
    }

    std::cout << "Check the sum in your file " << sumFile << std::endl;

    return 0;
}
