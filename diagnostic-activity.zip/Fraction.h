// Fraction.h
#ifndef FRACTION_H_
#define FRACTION_H_

#include <iostream>

class Fraction { //define class
private:
    int numerator;
    int denominator;

    int gcd(int a, int b);

public:
    Fraction(); //set constructor 
    Fraction(int num, int den);
    void setNum(int num);
    void setDen(int den);
    int getNum() const;
    int getDen() const;
    void printFraction() const;
    void simplifyFraction();
    void normalizeSign();
    double calcRealValue() const;
    Fraction sumFractions(const Fraction& f) const;
    Fraction multiplyFractions(const Fraction& f) const;
};

#endif 
