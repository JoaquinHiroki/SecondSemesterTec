#include "MatFrac.h"

MatFrac::MatFrac() {}

MatFrac::MatFrac(const std::vector<std::vector<Fraction>>& mat) : matrix(mat) {}

int MatFrac::getRows() const {
    return matrix.size();
}

int MatFrac::getCols() const {
    return (matrix.empty() ? 0 : matrix[0].size());
}

std::vector<std::vector<Fraction>> MatFrac::getMatrix() const {
    return matrix;
}

void MatFrac::printMatrix() const {
    for (const auto& row : matrix) {
        for (const auto& elem : row) {
            elem.printFraction();
            std::cout << "\t";
        }
        std::cout << std::endl;
    }
}

MatFrac MatFrac::addMatrices(const MatFrac& mat) const {
    int rows1 = getRows();
    int cols1 = getCols();
    int rows2 = mat.getRows();
    int cols2 = mat.getCols();

    int maxRows = std::max(rows1, rows2); //determine the dimensions
    int maxCols = std::max(cols1, cols2);

    std::vector<std::vector<Fraction>> result(maxRows, std::vector<Fraction>(maxCols)); //initialize third matrix

    for (int i = 0; i < maxRows; ++i) { //make the addition
        for (int j = 0; j < maxCols; ++j) {
            Fraction f1 = (i < rows1 && j < cols1) ? matrix[i][j] : Fraction();
            Fraction f2 = (i < rows2 && j < cols2) ? mat.matrix[i][j] : Fraction(); 
            result[i][j] = f1.sumFractions(f2);
        }
    }

    return MatFrac(result);
}
