#ifndef MATFRAC_H_
#define MATFRAC_H_

#include <vector>
#include "Fraction.h"

class MatFrac { //class
private:
    std::vector<std::vector<Fraction>> matrix;

public:
    MatFrac();
    MatFrac(const std::vector<std::vector<Fraction>>& mat);
    int getRows() const;
    int getCols() const;
    std::vector<std::vector<Fraction>> getMatrix() const;
    void printMatrix() const;
    MatFrac addMatrices(const MatFrac& mat) const;
};

#endif 
