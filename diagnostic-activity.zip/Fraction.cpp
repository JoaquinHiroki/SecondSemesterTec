#include "Fraction.h"

Fraction::Fraction() : numerator(0), denominator(1) {} //set constructor

Fraction::Fraction(int num, int den) : numerator(num), denominator(den) {}

int Fraction::gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

void Fraction::setNum(int num) {
    numerator = num;
    simplifyFraction();
    normalizeSign();
}

void Fraction::setDen(int den) {
    if (den == 0) {
        std::cout << "Denominator cant be 0" << std::endl;
        return;
    }
    denominator = den;
    simplifyFraction();
    normalizeSign();
}

int Fraction::getNum() const {
    return numerator;
}

int Fraction::getDen() const {
    return denominator;
}

void Fraction::printFraction() const {
    std::cout << numerator << "/" << denominator;
}

void Fraction::simplifyFraction() {
    int common_divisor = gcd(numerator, denominator);
    numerator /= common_divisor;
    denominator /= common_divisor;
}

void Fraction::normalizeSign() {
    if (denominator < 0) {
        numerator *= -1;
        denominator *= -1;
    }
}

double Fraction::calcRealValue() const {
    return static_cast<double>(numerator) / denominator;
}

Fraction Fraction::sumFractions(const Fraction& f) const {
    int new_num = numerator * f.denominator + f.numerator * denominator;
    int new_den = denominator * f.denominator;
    return Fraction(new_num, new_den);
}

Fraction Fraction::multiplyFractions(const Fraction& f) const {
    int new_num = numerator * f.numerator;
    int new_den = denominator * f.denominator;
    return Fraction(new_num, new_den);
}
